function setup() {
  createCanvas(500, 400);
}

function draw() {
  background("hsla(210, 50%, 70%, .1)");
  
stroke("black");
  fill("darkgoldenrod")
  triangle(450, 100, 300, 200, 450, 300)
  fill("goldenrod")
  ellipse(200, 200, 300, 200)
  fill("white")
  ellipse (200, 175, 50, 50)
  ellipse (100, 175, 50, 50)
  fill("black")
  ellipse (200, 175, 25, 25)
  ellipse (100, 175, 25, 25)
  fill ("pink")
  ellipse (150, 250, 75, 25)
  fill("hsla(210, 50%, 50%, .1)")
  ellipse (60, 100, 40, 40)
  ellipse (40, 50, 30, 30)
  ellipse (80, 20, 20, 20)
  fill("darkgoldenrod")
  triangle(270, 200, 250, 250, 350, 230)
  fill("darkgoldenrod")
  triangle(150, 120, 180, 50, 250, 130)
  noStroke()
  fill("burlywood")
  rect (0, 375, 500, 25)
  
  
}